package zad2;
import java.io.File;
import java.util.*;
import java.util.regex.*;

public class datesExtraction {
	
	public String datesString;
	public StringBuilder datesBuffer = new StringBuilder();
	
	public datesExtraction(){}
	
	public void readDatesFile(String filePath){
		
		try {
		Scanner fscan = new Scanner(new File(filePath));
		readLineFromFile(fscan);
		
		fscan.close();
		
		} catch (Exception exc) {
			System.out.println(exc);
			System.exit(0);
			
		}
	 }
	
	 public void readLineFromFile(Scanner fileScan){
		 
		 try{
			 if(fileScan.hasNext()){
			 while(fileScan.hasNextLine()){
					datesBuffer.append(fileScan.nextLine());
				}
			 } else {
				 System.out.println("Plik jest pusty");
				 System.exit(0);
			 }
		 } catch (Exception exc){
			 System.out.println(exc);
			 System.exit(0);
		 }
		 
	 }
	 
	 public void showDatesFile(){
		 datesString = datesBuffer.toString();
		 System.out.println(datesString);
		 
	 }
	 
	 public void datesParser(){
		 datesString = datesBuffer.toString();
		 String myPattern = "([1-9][\\d][\\d][\\d]-[0-1][0-9]-[0-9]+)";
		 
		 String splitter = "-";
		 String currentDate = "";
		 
		 String[] dateTab;
		 
		 Pattern myDatePattern = Pattern.compile(myPattern);
		 
		 Matcher myMatcher = myDatePattern.matcher(datesString);
		 Calendar cal = Calendar.getInstance();
		 
		
		 
		 try {
		 while(myMatcher.find()){
			 
			 dateTab = myMatcher.group().split(splitter);
			
			 
			 if(Integer.parseInt(dateTab[0]) <= 3000){
				 
				 cal.set(Calendar.YEAR, Integer.parseInt(dateTab[0]));
				 
			 } else {
				 continue;
			 }
			 
			 if(Integer.parseInt(dateTab[1]) <= 12 & Integer.parseInt(dateTab[1]) != 0){
				 
				 cal.set(Calendar.MONTH, Integer.parseInt(dateTab[1])-1);
				
			 }  else {
				 continue;
			 }
			 
			 
			 if(Integer.parseInt(dateTab[2]) <= cal.getActualMaximum(Calendar.DAY_OF_MONTH)&Integer.parseInt(dateTab[2]) != 0){
				
				 currentDate = currentDate + dateTab[0] + "-" + dateTab[1] + "-" + dateTab[2] + " ";
				 
			 }  else {
				 continue;
			 }
			
			
			
		 }
		 
		 if(currentDate == ""){
			 System.out.println("Nie znaleziono zadnej poszukiwanej frazy");
		 } else {
		 showDate(currentDate);
		 }
		 } catch (Exception exc){
			 System.out.println("Blad danych");
			 System.exit(0);
		 }
		
	 }
	 
	 public static void showDate(String s){
		  System.out.print(s.trim());
		 
	 }
	
	
	
	

}
