/**
 *
 *  @author Więcko Konrad PD2193
 *
 */

package zad2;


public class Main {

  public static void main(String[] args) {
	  
	  String fname = System.getProperty("user.home") + "/test/daty.txt";  
	    
	  datesExtraction firstDatesFile = new datesExtraction();
	  firstDatesFile.readDatesFile(fname);
	  	  firstDatesFile.datesParser();
	  
  }
}
