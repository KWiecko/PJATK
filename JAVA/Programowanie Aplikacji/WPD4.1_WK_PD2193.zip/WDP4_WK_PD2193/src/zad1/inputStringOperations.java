package zad1;
import javax.swing.JOptionPane;
import java.util.regex.*;

public class inputStringOperations {
	
	public String userInputString;
	public String userRegex;
	public String[] splitString;

	public inputStringOperations(){}
	
	public void getUserInputString(){
		
		userInputString = JOptionPane.showInputDialog("Prosze podaj dowolny napis.");
		
		
		if(userInputString.length() == 0){
			
			System.out.println("1) 0");		//punkt 1) jest jedynym rozw2iazywalnym poleceniem gdy dlugosc lancucha == 0 - dlatego zdecydowalem sie ja wydrukowac przed zakonczeniem programu
			System.out.println("Nie wprowadzono zadnego znaku");
			System.exit(0);
		}
		
		
	}
	
	
	public void getUserInputStringLength(){
		
		System.out.println("1) " + userInputString.length());
	}
	
	public void getFirstAndLastLetter(){
		char first = userInputString.charAt(0);
		char last = userInputString.charAt(userInputString.length()-1);
		System.out.println("2) "  + first + " " + last);
		
	}
	
	public void getFourthToLast(){
		
		try{
		 String currentString = userInputString.substring(3, userInputString.length());
		 System.out.println("3) " + currentString);
		} catch (Exception exc) {
			System.out.println("Blad danych, zamykam program.");
			System.exit(0);
		}
		  
	}
	
	
	public void getFourthtoPenultimate(){
		try{
		String currentString = userInputString.substring(3, userInputString.length()-1);
		 System.out.println("4) " + currentString);
		 } catch (Exception exc) {
			System.out.println("Blad danych, zamykam program.");
			System.exit(0);
		}
		
	}
	
	public void getUserRegex(){
		
		userRegex = JOptionPane.showInputDialog("Prosze podaj szukana fraze.");
		
		if(userRegex.length() == 0){
			
			System.out.println("Nie wprowadzono zadnego znaku");
			System.exit(0);
		}
	}
	
	public void howManyTimes() {
		try{
		Pattern localRegex = Pattern.compile(userRegex);
		Matcher localText2Match = localRegex.matcher(userInputString);
		int i = 0;
		while (localText2Match.find()){
			i++;			
		}
		
		System.out.println("5) " + i);
		} catch (Exception exc) {
			System.out.println("Blad danych, zamykam program.");
			System.exit(0);
		}
	}
	
	public void userInputStringSplitter(){
		try{
		String splitPattern = "[ ,\\.;]+";
		splitString = userInputString.split(splitPattern);
		
		System.out.print("6)");
		int i = 0;
		while (i < splitString.length){
			System.out.print(" " + splitString[i]);
			i++;
		}
		System.out.println("");
		} catch (Exception exc) {
			System.out.println("Blad danych, zamykam program.");
			System.exit(0);
		}
	}
	
	public void doesLastequalFirst(){
		System.out.println("7) " + splitString[0].equals(splitString[splitString.length-1]));
	}
	
}
