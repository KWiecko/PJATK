/**
 *
 *  @author Więcko Konrad PD2193
 *
 */

package zad1;



public class Main {

  public static void main(String[] args) {
	  
	  inputStringOperations myString = new inputStringOperations();
	  myString.getUserInputString();
	  myString.getUserInputStringLength();
	  myString.getFirstAndLastLetter();
	  myString.getFourthToLast();
	  myString.getFourthtoPenultimate();
	  myString.getUserRegex();
	  myString.howManyTimes();
	  myString.userInputStringSplitter();
	  myString.doesLastequalFirst();
  }
}
