/**
 *
 *  @author Więcko Konrad PD2193
 *
 */

package zad3;


public class Main {

  public static void main(String[] args) {
	  simpleCal cal1 = new simpleCal();
	  cal1.getUserInput();
	  cal1.readUserInputDates();
	  cal1.getCalendar();
	  
  }
}
