package zad3;
import javax.swing.JOptionPane;
import java.util.*;

public class simpleCal {

	public String userInputString;
	public String[] dates;
	public String[] calStartDate = null;
	public String[] calEndDate = null;

	
	public simpleCal(){}
	
	public void getUserInput(){
		
		
		userInputString = JOptionPane.showInputDialog("Prosze podaj zakres dat (od do) w formacie \'YYYY-MM-DD YYYY-MM-DD\'");
		
		if(userInputString.length() == 0){
			System.out.println("Nie wprowadzono zadnego znaku");
			System.exit(0);
		}
		
	}
	
	public void readUserInputDates(){
		try{
			dates = userInputString.split(" ");
			//System.out.println(dates[0] + " " + dates[1]);
			String[] firstDate = decomposeDate(0);
			String[] lastDate = decomposeDate(1);
			dateCompare(firstDate, lastDate);
			calStartDate = firstDate;
			calEndDate = lastDate;
			
			
		} catch (Exception exc){
			System.out.println("Napis '" + userInputString + "' nie moze zostac zinterpretowany jako wlasciwa data");
			System.exit(0);
		}
		
		
		
	}
	
	public String[] decomposeDate(int i){
		String[] Date = null;
		try {
		
		Date = dates[i].split("-");
		//for(int j = 0 ; j < 3; j++)System.out.println(Date[j]);
			
		} catch (Exception exc){
			System.out.println("Napis '" + userInputString + "' nie moze zostac zinterpretowany jako wlasciwa data");
			System.exit(0);
		}
		return (Date);
	}
	
		
	
	public void dateCompare(String[] firstDate, String[] lastDate){
		Calendar calLocal1 = Calendar.getInstance();
		calLocal1.setLenient(false);
		Calendar calLocal2 = Calendar.getInstance();
		calLocal2.setLenient(false);
		try {
		calLocal1.set(Calendar.YEAR, Integer.parseInt(firstDate[0]));
		calLocal1.set(Calendar.MONTH, Integer.parseInt(firstDate[1])-1);
		calLocal1.set(Calendar.DATE, Integer.parseInt(firstDate[2]));
		
		calLocal2.set(Calendar.YEAR, Integer.parseInt(lastDate[0]));
		calLocal2.set(Calendar.MONTH, Integer.parseInt(lastDate[1])-1);
		calLocal2.set(Calendar.DATE, Integer.parseInt(lastDate[2]));
		
		if(calLocal1.getTimeInMillis() > calLocal2.getTimeInMillis()){
			System.out.println("Poczatkowa data starsza od koncowej");
			System.exit(0);
			
		} else {
			//System.out.println("Daty sa ok");
		 }
		} catch (Exception exc){
			System.out.println("Napis '" + userInputString + "' nie moze zostac zinterpretowany jako wlasciwa data");
			System.exit(0);
		}
		
	}
	
	public Calendar setCalDate(String[] date){
		
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, Integer.parseInt(date[0]));
		cal.set(Calendar.MONTH, Integer.parseInt(date[1])-1);
		cal.set(Calendar.DATE, Integer.parseInt(date[2]));
		//System.out.println("Data nadpisana");		
		return cal;
	}
	
	public void getCalendar(){
		
		
		
		try{
			Calendar calCurrent = Calendar.getInstance();
			Calendar calEnd = Calendar.getInstance();
			calCurrent.setLenient(true);
			calEnd.setLenient(true);
			calCurrent = setCalDate(calStartDate);
			calEnd = setCalDate(calEndDate);
			
			
			while(calCurrent.getTimeInMillis()<=calEnd.getTimeInMillis()){
			
				String date2Print = String.format("%td.%<tm.%<tY", calCurrent.getTimeInMillis());
				int a = (int)calCurrent.get(Calendar.DAY_OF_WEEK);
				String dayToPrint = dayOfWeek(a);
				System.out.println(date2Print + " " + dayToPrint);
				calCurrent.set(Calendar.DATE, calCurrent.get(Calendar.DATE)+1);
			}
		
		} catch (Exception exc){
			System.out.println("Napis '" + userInputString + "' nie moze zostac zinterpretowany jako wlasciwa data");
			System.exit(0);
		}
		
	}
	
	
	public String dayOfWeek(int i){
		String dayOfWeek = null;
		switch(i){
		 case 1 : dayOfWeek = "Pn"; break;
		 case 2 : dayOfWeek = "Wt"; break;
		 case 3 : dayOfWeek = "Sr"; break;
		 case 4 : dayOfWeek = "Cz"; break;
		 case 5 : dayOfWeek = "Pt"; break;
		 case 6 : dayOfWeek = "So"; break;
		 case 7 : dayOfWeek = "N"; break;
		 default  : System.out.println("Nieznany kod operacji");
		 
		 }
		
		
		return dayOfWeek;
	}
}
