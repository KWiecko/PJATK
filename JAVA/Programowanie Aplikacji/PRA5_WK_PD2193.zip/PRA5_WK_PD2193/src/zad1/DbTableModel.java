package zad1;



import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;



public class DbTableModel extends AbstractTableModel{
	
	String[] columnNames = {"Kraj", "Przyjazd", "Powrót", "Miejsce", "Cena", "Waluta"};
	TravelData travelDataUtils;
	Locale chosenLocSettings;
	String[] avaliableLanguages = {"pl", "en"};
	String[] avaliableLocales = {"pl_PL", "en_GB"};
	int languageIdx = 0;
	int localeIdx = 0;
	
	SimpleDateFormat  sdf = (SimpleDateFormat) DateFormat.getDateInstance();
	
	
	ArrayList<List<?>> tableModelDataSource;
	String[] localeStrings;
	Locale[] locales;
	String[] countryCont;
	Date[] arrDate;
	Date[] depDate;
	String[] dest;
	String[] priceString;
	Double[] price;
	String[] currString;
	Currency[] curr;
	
	
	public DbTableModel(ArrayList<List<?>> dataSource, ArrayList sqlColTypes,TravelData travelDataObj){
		
		tableModelDataSource = dataSource;
		travelDataUtils = travelDataObj;
		localeStrings = (String[]) dataSource.get(0).toArray(new String[0]);
		
		ArrayList<Locale> transferLocList =  mapStringsToLocale(localeStrings);
		locales = (Locale[]) transferLocList.toArray(new Locale[0]);
		countryCont = (String[]) dataSource.get(1).toArray(new String[0]);
		arrDate = (Date[]) dataSource.get(2).toArray(new Date[0]);
		depDate = (Date[]) dataSource.get(3).toArray(new Date[0]);
		dest = (String[]) dataSource.get(4).toArray(new String[0]);
		
		priceString = (String[]) dataSource.get(5).toArray(new String[0]);
		ArrayList<Double> transferPriceList = stringToDouble();
		price = (Double[]) transferPriceList.toArray(new Double[0]);
		
		currString = (String[]) dataSource.get(6).toArray(new String[0]);
		ArrayList<Currency> transferCurrList = stringToCurr();
		curr = (Currency[]) transferCurrList.toArray(new Currency[0]);

	}
	
	
	public int getColumnCount(){
		return columnNames.length;
	}
	
	public int getRowCount(){
		return countryCont.length;
	}
	
	public String getColumnName(int col){
		return columnNames[col];
	}
	
	public Class getColumnClass(int col){
		return getValueAt(0,col).getClass();
	}
	
	public boolean isCellEditable(int row, int col){
		boolean isEditable = false;
		
		return isEditable;
	}
	
	
	
	public Object getValueAt(int i, int j){
		Object o = null;
		

		
		String bundlePath = "zad1.destProps.dest_" + avaliableLanguages[languageIdx];
		ResourceBundle resLocal = 
				ResourceBundle.getBundle(bundlePath, new Locale(avaliableLanguages[languageIdx]));
		
		
		sdf.applyPattern("yyyy-MM-dd");
		
		switch(j){
		case 0 :o = (Object) travelDataUtils.countryTranslator.get(countryCont[i]).getDisplayCountry(new Locale(avaliableLanguages[languageIdx]));
				break;
		case 1 :o = (Object) sdf.format(arrDate[i]);
				break;
		case 2 :o = (Object) sdf.format(depDate[i]); 
				break;
		case 3 :o =(Object) resLocal.getString(dest[i]); 
				break;
		case 4 :Locale.setDefault(new Locale(avaliableLocales[localeIdx].split("_")[0], avaliableLocales[localeIdx].split("_")[1]));
				DecimalFormat nf = (DecimalFormat) NumberFormat.getInstance(Locale.getDefault());
				nf.setGroupingUsed(true);
				o = (Object) nf.format(price[i]);
				 //o = (Object) price[i];
				break;
		case 5 :o =(Object) curr[i].toString();
				break;
		
		}
		return o;
	}
	
	public void setValueAt(Object value, int i, int j){
		


	}
	
	ArrayList<Double> stringToDouble(){
		ArrayList<Double> priceList = new ArrayList<Double>();
		
		for(String s : priceString){
			priceList.add(Double.parseDouble(s));
			
		}
		
		return priceList;
	}
	
	ArrayList<Currency> stringToCurr(){
		ArrayList<Currency> currList = new ArrayList<Currency>();
		
		for(String singleCurr : currString){
			currList.add(Currency.getInstance(singleCurr));
		}
		return currList;
	}
	
	
	ArrayList<Locale> mapStringsToLocale(String[] inputLocList){
		
		ArrayList<Locale> locList = new ArrayList<Locale>();
		
		for (String iLLE : inputLocList){
			String localeString = iLLE.toString();
			String[] localeDef = localeString.split("_");
			if(localeDef.length == 1){
				locList.add(new Locale(localeDef[0]));
			}else{
				locList.add(new Locale(localeDef[0], localeDef[1]));	
			}
			
		}
		return locList;
	}
	
	public void changeLanguage(int newIdx, JTable table){
		int oldLangIdx = languageIdx;
		
		languageIdx = newIdx;
		if(oldLangIdx != languageIdx){
			String bundlePath = "zad1.destProps.colNames_" + avaliableLanguages[languageIdx];
			ResourceBundle rs = ResourceBundle.getBundle(bundlePath);
			for(int i = 0; i < columnNames.length; i++){
			columnNames[i] = rs.getString(columnNames[i]);
			
			table.getColumnModel().getColumn(i).setHeaderValue(columnNames[i]);	
			table.getTableHeader().repaint();
			}
		}

		
		fireTableDataChanged();
	}
	
	public void changeLocaleSettings(int newIdx){
		
		localeIdx = newIdx;
		fireTableDataChanged();
		
	}
	

}
