package zad1;

import java.util.*;
import java.util.Date;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.lang.reflect.*;
import java.math.BigDecimal;


public class Database {
	
	String driverName = "org.apache.derby.jdbc.EmbeddedDriver";
	Connection dbConnection;
	TravelData dbTravelData;
	boolean tableExistatnceIndicator = false;
	
	ArrayList<List<?>> tableDataSource = new ArrayList<List<?>>();
	ArrayList<String> sqlColTypes = new ArrayList<String>();
	HashMap<String, Method> rsGetters = new HashMap<String, Method>();
	
	public Database(String url, TravelData travelData){
		
		dbTravelData = travelData;
		fillMyMethodMap();
		
		try {
			Class.forName(driverName);
			dbConnection = DriverManager.getConnection(url + ";create=true");
			
			
			
		} catch(Exception exc) {
			exc.printStackTrace();
		}
		

		
	}
	
	
	public void create(){
		
		try{
			//System.out.println("Jesli tabela o nazwie 'offers' istnieje - kasuje tabele");
			
			Statement stmt = dbConnection.createStatement();
			String dropCTab = "DROP TABLE offers";
			int a = stmt.executeUpdate(dropCTab);
			
		}catch(SQLException exc){
			createTable();
			tableExistatnceIndicator = true;
			
		}
		
		if(!tableExistatnceIndicator){
			createTable();
		}

		
			try{
						

			SimpleDateFormat  sdf = (SimpleDateFormat) DateFormat.getDateInstance();
			sdf.applyPattern("yyyy-MM-dd");
			
			PreparedStatement stmt1 = dbConnection.prepareStatement("INSERT INTO offers VALUES(?, ?, ?, ?, ?, ?, ?)");
			for(int i = 0; i < dbTravelData.countryCont.size(); i++){
				stmt1.setString(1, dbTravelData.localisationRawDesignation.get(i));
				stmt1.setString(2, dbTravelData.countryCont.get(i));
				stmt1.setDate(3, java.sql.Date.valueOf(sdf.format(dbTravelData.arrDate.get(i))) );
				stmt1.setDate(4, java.sql.Date.valueOf( sdf.format(dbTravelData.depDate.get(i))) );
				stmt1.setString(5, dbTravelData.dest.get(i));
				stmt1.setString(6, dbTravelData.price.get(i).toString());
				//stmt1.setDouble(6, dbTravelData.price.get(i));
				stmt1.setString(7, dbTravelData.curr.get(i).toString());
				int a = stmt1.executeUpdate();
			//System.out.println(a);
			}
			dbConnection.commit();
		}catch(Exception exc){
			exc.printStackTrace();
		}
		
		createTableDataSource();
		

		
	}
	
	void fillMyMethodMap(){
		
		try{
			Class rcCLass = java.sql.ResultSet.class;
			rsGetters.put("VARCHAR", rcCLass.getMethod("getString", int.class));
			rsGetters.put("DATE", rcCLass.getMethod("getDate", int.class));
			rsGetters.put("DECIMAL", rcCLass.getMethod("getDouble", int.class));
		}catch(Exception exc){
			exc.printStackTrace();
		}
		
		
	}
	
	
	void createTableDataSource(){
		try{
			
			Statement stmt2 = dbConnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = stmt2.executeQuery("SELECT * FROM offers");
			ResultSetMetaData rsmd = rs.getMetaData();
			for(int i = 1; i <= rsmd.getColumnCount(); i++){
				rs.absolute(0);
				sqlColTypes.add(rsmd.getColumnTypeName(i).toString());
				List<Object> locList = new ArrayList<Object>();
				
				while(rs.next()){
					locList.add(rsGetters.get(rsmd.getColumnTypeName(i).toString()).invoke(rs, i));
					
				}
				tableDataSource.add(locList);
				
			}
			
		}catch(Exception exc){
			exc.printStackTrace();
		}
		
		
		
	}
	
	public void showGui(){
		DbTableModel tableModel = new DbTableModel(tableDataSource, sqlColTypes, dbTravelData);
		new DbTableView(tableModel);
	}
	
	public void createTable(){
		try{
			//System.out.println("tworze tabele");
			Statement stmt = dbConnection.createStatement();
			String cTab = "CREATE TABLE offers (locale_data VARCHAR(255),"
						 + "country_data VARCHAR(255),"
						 + "arr_date DATE,"
						 + "dep_date DATE,"
						 + "dest_data VARCHAR(255),"
						 + "price VARCHAR(255),"
						 + "curr VARCHAR(255))";
			int a = stmt.executeUpdate(cTab);
		}catch(Exception exc1){
			exc1.printStackTrace();
		}
	}
	

}
