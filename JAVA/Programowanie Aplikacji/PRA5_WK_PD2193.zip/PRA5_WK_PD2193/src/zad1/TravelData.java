package zad1;

import java.io.*;
import java.util.*;
import java.text.*;

public class TravelData {
	
	ArrayList<String>   localisationRawDesignation = new ArrayList<String>();
	ArrayList<Locale> 	localisationList = new ArrayList<Locale>(); 	//0
	ArrayList<String> 	countryCont = new ArrayList<String>();			//1
	ArrayList<Date>   	arrDate = new ArrayList<Date>();				//2
	ArrayList<Date>   	depDate = new ArrayList<Date>();				//3
	ArrayList<String>   dest = new ArrayList<String>();					//4
	ArrayList<Double>   price = new ArrayList<Double>();				//5
	ArrayList<Currency> curr = new ArrayList<Currency>();				//6
	
	HashMap<String, Locale> countryTranslator = new HashMap<String, Locale>();
	String[] contractorsLocalisations = {"pl_PL", "en_GB"};
	File[] offers;
	
	
	public TravelData(File dataDir){
		
		fillCountryTranslator();
		
		offers = dataDir.listFiles();
		int caseCounter = 0;
		
		for(File offer : offers){
			try{
				Scanner sc = new Scanner(offer);
				StringTokenizer st = new StringTokenizer(sc.nextLine(), "\t");
				
				caseCounter = 0;
				while (st.hasMoreTokens()){
					listFiller(caseCounter, st.nextToken());
					caseCounter++;
				}
				sc.close();
				
			}catch(Exception exc){
				
			}
			
			
		}
		
	}
	
	void listFiller(int listId, String data){
		
		switch(listId){
		//locale extraction
		case 0: localisationRawDesignation.add(data);
				String[] localeDef = data.split("_");
				if(localeDef.length == 1){
					localisationList.add(new Locale(localeDef[0]));
				}else{
					localisationList.add(new Locale(localeDef[0], localeDef[1]));	
				}
				break;
				
		case 1: countryCont.add(data);
				break;
				
		case 2: 
			try{
				arrDate.add(new SimpleDateFormat("yyyy-MM-dd").parse(data));
			}catch(Exception exc){
				System.out.println("Incorrect arrival date");				
			}
			
				break;
		case 3: 
			try{
				depDate.add(new SimpleDateFormat("yyyy-MM-dd").parse(data));
			}catch(Exception exc){
				System.out.println("Incorrect departure date");				
			}
				break;
		case 4: dest.add(data);
				break;
				
		case 5:	DecimalFormat df = (DecimalFormat) 
									NumberFormat.getInstance(localisationList.get(price.size()));
					try{
						price.add((double) df.parse(data));
					}catch(Exception exc){
						exc.printStackTrace();
					}		
		
				break;
				
		case 6: curr.add(Currency.getInstance(data));
		}
		
	}
	
	public List<String> getOffersDescriptionsList(String locale, String dateFormat){
		
		List <String> locListOfOffers = new ArrayList<String>();
		
		SimpleDateFormat  sdf = (SimpleDateFormat) DateFormat.getDateInstance();
		sdf.applyPattern(dateFormat);
		
		//zakładam, że mozę pojawić się jedynie kod języka -> potrzebny konstruktor new Locale('kod języka');
		DecimalFormat nf = (DecimalFormat) NumberFormat.getInstance(new Locale(locale.split("_")[0]));
		nf.setGroupingUsed(true);

		
		
		Locale.setDefault(new Locale(locale.split("_")[0]));
		String bundlePath = "zad1.destProps.dest_" + locale.split("_")[0];
		
		ResourceBundle resLocal = 
				ResourceBundle.getBundle(bundlePath, Locale.getDefault());
		
		for(int i = 0; i < countryCont.size(); i++){

			locListOfOffers.add(countryTranslator.get(countryCont.get(i)).getDisplayCountry(new Locale(locale.split("_")[0]))
					+
					" "
					+
					sdf.format(arrDate.get(i))
					+
					" "
					+
					sdf.format(depDate.get(i))
					+
					" "
					+
					resLocal.getString(dest.get(i))
					+
					" "
					+
					nf.format(price.get(i))
					+
					" "
					+
					curr.get(i).toString()
					
					);
		}
		
		return locListOfOffers;
	}
	
	void fillCountryTranslator(){
		String locCountry;
		for(int q = 0 ; q < contractorsLocalisations.length; q++){
			
			String[] localeToMap = contractorsLocalisations[q].split("_");
			Locale.setDefault(new Locale(localeToMap[0]));						
			Locale[] loc = Locale.getAvailableLocales();
			
			
			for(int i = 0; i < loc.length; i++){
				String countryCode = loc[i].getCountry();
				if(countryCode.equals(""))continue;
				locCountry = loc[i].getDisplayCountry();
				countryTranslator.put(locCountry, loc[i]);
			}
					
		}
		Locale.setDefault(new Locale("pl"));
	}
	
	public void printMyList(ArrayList<?> myList){
		
		for(Object myListElement : myList){
			
			System.out.println(myListElement.toString());
		}
	}

}
