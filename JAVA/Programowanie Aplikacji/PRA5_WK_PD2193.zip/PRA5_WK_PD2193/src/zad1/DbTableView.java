package zad1;


import javax.swing.*;
import javax.swing.table.*;

import javax.swing.DefaultCellEditor.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import javax.swing.table.*;


public class DbTableView extends JFrame{
	
	DbTableModel offersDbModel;
	
	public DbTableView(DbTableModel myDbModel){
		
		offersDbModel = myDbModel;
		JTable offerTab = new JTable(offersDbModel);

		JComboBox languageSelect = new JComboBox(offersDbModel.avaliableLanguages);
		languageSelect.setPreferredSize(new Dimension(80,30));
		
		languageSelect.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				JComboBox source =(JComboBox)  e.getSource();
				
				offersDbModel.changeLanguage(source.getSelectedIndex(), offerTab);
				
			}
			
		});
		

		
		JComboBox localeSelect = new JComboBox(offersDbModel.avaliableLocales);
		localeSelect.setPreferredSize(new Dimension(80,30));
		
		localeSelect.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e){
				JComboBox source =(JComboBox)  e.getSource();
				

				offersDbModel.changeLocaleSettings(source.getSelectedIndex());
				

			}
			
		});
		
		
		JPanel langLocaleSel = new JPanel();
		langLocaleSel.setLayout(new FlowLayout());
		langLocaleSel.add(new JLabel("Język/Language: "));
		langLocaleSel.add(languageSelect);
		langLocaleSel.add(new JLabel("Ust. lokalne/Locale: "));
		langLocaleSel.add(localeSelect);
		
		JScrollPane sc = new JScrollPane(offerTab);
		add(sc, "North");
		add(langLocaleSel, "South");
		
	    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	    pack();
	    setLocationRelativeTo(null);
	    setVisible(true);
		
		
	}
	


}
