package zad2;

import java.beans.*;

public class PriceLimitator implements VetoableChangeListener {
	
	public double minPrice;
	
	public PriceLimitator (double locMinPrice){
		minPrice = locMinPrice;
	}
	
	public void vetoableChange(PropertyChangeEvent e) 
				throws PropertyVetoException{
		
		Double newVal = (Double) e.getNewValue();
		double val = newVal.doubleValue();
		if (val < minPrice){
			String msg = "Price change to: " + val + " not allowed"; 
			throw new PropertyVetoException(msg, e);
		}
		
	}

}
