/**
 *
 *  @author Więcko Konrad PD2193
 *
 */

package zad2;

import java.beans.*;
import java.io.*;

public class Purchase implements Serializable, PropertyChangeListener  {
	
	String product = null;
	String data = null;
	Double price = new Double(1000);
	
	PropertyChangeSupport chg = new PropertyChangeSupport(this);
	VetoableChangeSupport veto = new VetoableChangeSupport(this);
	
	
	public Purchase(){}
	public Purchase(String locProd, String locData, double locPrice){
		setProduct(locProd);
		setData(locData);
		try {setPrice(locPrice);}catch (Exception exc){}
		
	}
	
	/*---  getters  ---*/
	
	public synchronized String getProduct(){
		return product;
	}
	
	public synchronized String getData(){
		return data;
	}
	
	public synchronized Double getPrice(){
		return price;
	}
	
	/*---  setters  ---*/
	
	private synchronized void setProduct(String locNewProduct){
		product = locNewProduct;
			
	}
	
	public synchronized void setData(String locNewData){
		String oldData = data;
		data = locNewData;
		chg.firePropertyChange("data", oldData, locNewData);
	}
	
	public synchronized void setPrice(double locNewPrice)
							 throws PropertyVetoException{
		double oldPrice = price.doubleValue();
		veto.fireVetoableChange("price", new Double(oldPrice), new Double(locNewPrice));
		price = new Double(locNewPrice);
		chg.firePropertyChange("price", new Double(oldPrice), new Double(locNewPrice));
	}
	

	  public synchronized void addPropertyChangeListener(PropertyChangeListener listener) {
		  chg.addPropertyChangeListener(listener);
	  }

	  public synchronized void removePropertyChangeListener(PropertyChangeListener l) {
		  chg.removePropertyChangeListener(l);
	  }
	  
	  public synchronized void addVetoableChangeListener(VetoableChangeListener l) {
			veto.addVetoableChangeListener(l);
		}

		public synchronized void removeVetoableChangeListener(VetoableChangeListener l) {
			veto.removeVetoableChangeListener(l);
		}
		
		public void propertyChange(PropertyChangeEvent e)  {
			if (e.getPropertyName().equals("price")){
				Double oldValD = (Double) e.getOldValue();
				double oldVal = oldValD.doubleValue();
				Double newValD = (Double) e.getNewValue();
				double newVal = newValD.doubleValue();
				System.out.println("Change value of: " + e.getPropertyName() + " from: " + oldVal + " to: " + newVal);
				
			} else {
				String oldVal = (String) e.getOldValue();
				String newVal = (String) e.getNewValue();
				System.out.println("Change value of: " + e.getPropertyName() + " from: " + oldVal + " to: " + newVal);
				
			}
		    
		    
		    
		   }
		
		public String toString(){
			String puchaseStr = "Purchase [prod=" + product + ", data=" + data + ", price=" + price + "]";
			return puchaseStr;
			
		}
}  
