/**
 *
 *  @author Więcko Konrad PD2193
 *
 */

package zad1;

import java.util.*;
import java.lang.reflect.*;
import java.math.*;

public class Calc {
	 String result = null;
	 String eqArray[] = null;
	 HashMap<String, Method> eqMap = new HashMap <String, Method>();
	 HashMap<String, Method> eqMapDiv = new HashMap <String, Method>();
	
	public Calc(){}
	
	public String doCalc(String cmd){
		
		try {	
				eqArray = extractEquation(cmd);
				fillMyEqMap();
				BigDecimal trans= (BigDecimal) eqMap.get(eqArray[1]).invoke(new BigDecimal(eqArray[0]), new BigDecimal(eqArray[2]));
				result = trans.stripTrailingZeros().toString();
				
		} catch (Exception exc){
			try {
				BigDecimal trans= (BigDecimal) eqMapDiv.get(eqArray[1]).invoke(new BigDecimal(eqArray[0]), new BigDecimal(eqArray[2]), 
																			7, RoundingMode.HALF_UP);
				result = trans.stripTrailingZeros().toString();
			} catch (Exception exc1) {
				result = "Invalid command to calc";
			}
					
		}
		
		return result;
		
	}
	
	private String [] extractEquation(String eqString){
		String eqComponents[] = eqString.split("[\\s\\t]");
		return eqComponents;
		
	}
	

	
	private void fillMyEqMap(){
		
		try {
			Class divideArgs[] = {Class.forName("java.math.BigDecimal"), int.class , Class.forName("java.math.RoundingMode")};
			Class bd = Class.forName("java.math.BigDecimal");
			eqMap.put("+", bd.getMethod("add", Class.forName("java.math.BigDecimal")));
			eqMap.put("-", bd.getMethod("subtract", Class.forName("java.math.BigDecimal")));
			eqMap.put("*", bd.getMethod("multiply", Class.forName("java.math.BigDecimal")));
			eqMapDiv.put("/", bd.getMethod("divide", divideArgs));
		} catch (Exception exc){
			result = "Invalid command to calc";
		}
		
		
		
				
	}
	
	
	
}  
