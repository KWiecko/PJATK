/**
 *
 *  @author Więcko Konrad PD2193
 *
 */

package zad3;

import javax.swing.SwingUtilities;



public class Main {

  public static void main(String[] args) {
	  SwingUtilities.invokeLater( new Runnable() {
	        public void run() {

	        	new NewBookTableView();

	        }
	     });
	 

	  
	  
  }
}
