package zad3;


import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.File;
import javax.imageio.*;
import java.awt.image.*;
import java.net.*;
import java.io.*;
import java.awt.image.BufferedImage;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class NewBookTableModel extends AbstractTableModel{
	
	
	String[] columnNames = {"Autor", "Tytul", "Cena", "Okladka", "Usun"};
	
	ArrayList <String> authors = new <String> ArrayList();
	ArrayList <String> titles = new <String> ArrayList();
	ArrayList <JTextField> prices = new <JTextField> ArrayList();
	ArrayList<String> firstPagePath = new <String> ArrayList();
	ArrayList <ImageIcon> firstPages = new <ImageIcon> ArrayList();
	ArrayList <Boolean> toDelete = new <Boolean> ArrayList();
	
	public NewBookTableModel(){
		readData();
		readFirstPages();
		

	}
	
	public void readData(){
		
		try{
			
			Scanner sc = new Scanner(new File("bookInfo.txt"));
			while(sc.hasNextLine()){
				
				StringTokenizer st = new StringTokenizer(sc.nextLine(), ",");
				authors.add(st.nextToken());
				titles.add(st.nextToken());
				
				JTextField  locJTF = new JTextField();
				Double locPriceVal = Double.parseDouble(st.nextToken());
				
				String locPriceValString = locPriceVal.toString();
				locJTF.setText(locPriceValString);
				
				prices.add(locJTF);
				firstPagePath.add(st.nextToken().trim()+".png");
				
				toDelete.add(false);				
			}
			
			sc.close();
		}catch(Exception exc){
			
			//System.out.println(exc);
		}
		
	}
	
	public void readFirstPages(){
		
		Iterator iter = firstPagePath.iterator();
		
		while(iter.hasNext()){
			String path = iter.next().toString();
			File firstPageFile = new File(path);
			BufferedImage bi = null;
			ImageIcon ic = new ImageIcon();

			
			try{
				bi = new BufferedImage(507,477,BufferedImage.TYPE_INT_ARGB);
				bi = ImageIO.read(firstPageFile);


			}catch(Exception exc){
				System.out.println(exc);
			}
			
			
			
			//locLab.setIcon(ic);
			ic = new ImageIcon(bi);
			firstPages.add(ic);
			
			
		}
		
		
	}
	
	
	public void printMyList(ArrayList myList){
		Iterator iter = myList.iterator();
		
		while(iter.hasNext()){
			System.out.println(iter.next());
		}
	}
	


	public int getColumnCount(){
		
		return columnNames.length;
		
	}
	
	public int getRowCount(){
		
		return authors.size();
	}
	
	public String getColumnName(int col){
		
		return columnNames[col];
	}
	
	public Class getColumnClass(int col){
		
		return getValueAt(0, col).getClass();
				
	}
	
	public boolean isCellEditable(int row, int col){
		
		boolean isEditable;
		
		if(col == 2 || col == 4){
			isEditable = true;
		} else {
			isEditable = false;
		}
		
		return isEditable;
		
		
	}
	
	public Object getValueAt(int i, int j){
		Object o = null;
		
		switch(j)
		{
		case 0: o = (Object) authors.get(i);
				break;
		case 1: o = (Object) titles.get(i);
				break;
		case 2: o = (Object) prices.get(i).getText();
				break;
		case 3: o = (Object) firstPages.get(i);
				break;
		case 4: o = (Object) toDelete.get(i);
				break;
		}
		
		return o ;
	}
	
	public double checkIfDouble(Object value){
		
		final String Digits     = "(\\p{Digit}+)";
		final String HexDigits  = "(\\p{XDigit}+)";
		// an exponent is 'e' or 'E' followed by an optionally 
		// signed decimal integer.
		final String Exp        = "[eE][+-]?"+Digits;
		final String fpRegex    =
		    ("[\\x00-\\x20]*"+ // Optional leading "whitespace"
		    "[+-]?(" +         // Optional sign character
		    "NaN|" +           // "NaN" string
		    "Infinity|" +      // "Infinity" string

		    // A decimal floating-point string representing a finite positive
		    // number without a leading sign has at most five basic pieces:
		    // Digits . Digits ExponentPart FloatTypeSuffix
		    // 
		    // Since this method allows integer-only strings as input
		    // in addition to strings of floating-point literals, the
		    // two sub-patterns below are simplifications of the grammar
		    // productions from the Java Language Specification, 2nd 
		    // edition, section 3.10.2.

		    // Digits ._opt Digits_opt ExponentPart_opt FloatTypeSuffix_opt
		    "((("+Digits+"(\\.)?("+Digits+"?)("+Exp+")?)|"+

		    // . Digits ExponentPart_opt FloatTypeSuffix_opt
		    "(\\.("+Digits+")("+Exp+")?)|"+

		    // Hexadecimal strings
		    "((" +
		    // 0[xX] HexDigits ._opt BinaryExponent FloatTypeSuffix_opt
		    "(0[xX]" + HexDigits + "(\\.)?)|" +

		    // 0[xX] HexDigits_opt . HexDigits BinaryExponent FloatTypeSuffix_opt
		    "(0[xX]" + HexDigits + "?(\\.)" + HexDigits + ")" +

		    ")[pP][+-]?" + Digits + "))" +
		    "[fFdD]?))" +
		    "[\\x00-\\x20]*");// Optional trailing "whitespace"
		
		String localPrice = null;
		Double localPriceDouble = null;
		if (value instanceof String){
			localPrice = (String) value;
		}

		if (Pattern.matches(fpRegex, localPrice)){
			localPriceDouble = Double.valueOf(localPrice);
			
		} else {
			localPriceDouble = -1.0;
			
		}
		
		return localPriceDouble;
		
	}
	
	public void setValueAt(Object value, int i, int j) {
		
		switch(j)
		{
		case 0: authors.set(i, (String) value);
				break;
		case 1: titles.set(i, (String) value);
				break;
		case 2: 
				Double localPriceDouble = null;				
				localPriceDouble = checkIfDouble( value);				
				prices.get(i).setText(localPriceDouble.toString());				
				fireTableCellUpdated(i, j);
				break;
		case 3: firstPages.set(i, (ImageIcon) value);
				break;
		case 4: 
				toDelete.set(i, (Boolean) value);
				
		}
		
	
		
	}
	
	public void readAddedCover(String path){
		
		path = path + ".png";
		File firstPageFile = new File(path);
		
		if(!firstPageFile.exists()){
			System.out.println(firstPageFile.toString());
			System.out.println("Nie znaleziono pliku o podanej nazwie, jako okladke laduje plik brak.png");
			firstPageFile = new File("brak.png");
		}
		BufferedImage bi = null;
		ImageIcon ic = new ImageIcon();

		
		try{
			bi = new BufferedImage(507,477,BufferedImage.TYPE_INT_ARGB);
			bi = ImageIO.read(firstPageFile);


		}catch(Exception exc){
			
			System.out.println(exc);
		}
		
		
		

		ic = new ImageIcon(bi);
		firstPages.add(ic);
		
	}
	
	public void addRow(Object authorToAdd,
					   Object titleToAdd,
					   Object priceToAdd,
					   Object imagePathToAdd){
		
		
		authors.add((String) authorToAdd);
			
		titles.add((String) titleToAdd);
			
		Double localPriceDouble = null;				
		localPriceDouble = checkIfDouble( priceToAdd);
		prices.add(new JTextField(localPriceDouble.toString()));

		readAddedCover((String) imagePathToAdd);
		
		toDelete.add(false);
				
		
		fireTableDataChanged();
		
	}
	

	
}
