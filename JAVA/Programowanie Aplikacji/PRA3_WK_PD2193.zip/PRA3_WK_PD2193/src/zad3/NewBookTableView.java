package zad3;

import javax.swing.*;
import javax.swing.table.*;

import javax.swing.DefaultCellEditor.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class NewBookTableView extends JFrame{

	public NewBookTableView(){
		
		NewBookTableModel nbtm = new NewBookTableModel();
		
		
		JTable jTab = new JTable(nbtm);
		jTab.getColumn("Cena").setCellEditor(new DefaultCellEditor(new JTextField()));

		
		jTab.setRowHeight(200);
		jTab.getModel().addTableModelListener(new TableModelListener(){
			
			public void tableChanged(TableModelEvent e){
				Class jtf = (Class) e.getSource().getClass();
				int j = e.getFirstRow();
			}
		});
		
		
		JScrollPane sc = new JScrollPane(jTab);
		// panel dodawania ksiazek
		JPanel addBookPanel = new JPanel();
		addBookPanel.setLayout(new FlowLayout());
		//pola wpisywania danych
		DefaultComboBoxModel inputAuthorModel = new DefaultComboBoxModel();
		JComboBox inputAuthor = new JComboBox(inputAuthorModel);
		fillAuthorsList(inputAuthorModel, nbtm.authors);
		inputAuthor.setEditable(true);

		
		inputAuthor.setToolTipText("Podaj autora");
		inputAuthor.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.red), "Autor nowej pozycji"));
		JTextField inputTitle = new JTextField("Podaj tytul");
		inputTitle.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.red), "Tytul nowej pozycji"));
		JTextField inputPrice = new JTextField("Podaj cene");
		inputPrice.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.red), "Cena nowej pozycji"));
		JTextField inputCover = new JTextField("brak");
		inputCover.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.red), "Nazwa okladki"));
		
		JButton addButton = new JButton("Dodaj do listy");
		
		addButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				
				boolean isElementPresent = false;
				
				for(int i = 0; i < inputAuthor.getItemCount(); i++){
					
					if(inputAuthor.getSelectedItem().toString().equals(inputAuthor.getItemAt(i))){
						isElementPresent = true;
					} else {
						isElementPresent = false;
					}
					
				}
				
				if (!isElementPresent){
					inputAuthor.addItem(inputAuthor.getSelectedItem().toString());	
				}
				
				
				nbtm.addRow((Object) inputAuthor.getSelectedItem().toString(),
							(Object) inputTitle.getText(),
							(Object) inputPrice.getText(),
							(Object) inputCover.getText());
				
				inputTitle.setText("Podaj tytul");
				inputPrice.setText("Podaj cene");
				inputCover.setText("brak");
			}
		});
		
		JButton remButton = new JButton("Usun z listy");
		
		remButton.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e){
				
				ArrayList <Integer> idxToRemove = new <Integer> ArrayList();
				
				for(int i = nbtm.toDelete.size() - 1; i >= 0; i--){
					
					if(nbtm.toDelete.get(i)){
						idxToRemove.add((Integer) i);
					}
					
				}
				

					
				for(int i = 0; i < idxToRemove.size(); i ++){
						
						int rowToRemove = idxToRemove.get(i);
					
						nbtm.authors.remove(rowToRemove);
						nbtm.titles.remove(rowToRemove);
						nbtm.prices.remove(rowToRemove);
						nbtm.firstPages.remove(rowToRemove);
						nbtm.toDelete.remove(rowToRemove);
						
				}
				nbtm.fireTableDataChanged();
			}
			
		});
		
		addBookPanel.add(inputAuthor);
		addBookPanel.add(inputTitle);
		addBookPanel.add(inputPrice);
		addBookPanel.add(inputCover);
		addBookPanel.add(addButton);
		addBookPanel.add(remButton);
		
		addBookPanel.setSize(30, 2000);;
		
		add(sc);
		add(addBookPanel, "South");
		
	    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	    pack();
	    setLocationRelativeTo(null);
	    setVisible(true);
		
		
		
	}
	
	public void fillAuthorsList(DefaultComboBoxModel cbModel, ArrayList listToAdd){
		

		ArrayList <String> listForCombo = new <String> ArrayList();
		
		for(int q = 0; q < listToAdd.size(); q++){
			listForCombo.add((String) listToAdd.get(q));	
		}
		
		int maxLoopIdx = listForCombo.size();
		for(int i = 0; i < listForCombo.size(); i++){
			maxLoopIdx = listForCombo.size();
			for(int j = i+1; j < maxLoopIdx; j++){
				if(listForCombo.get(i).equals(listForCombo.get(j))){
					listForCombo.remove(j);
				}
			}
			
		}
		
		Iterator iter = listForCombo.iterator();
		while(iter.hasNext()){
			cbModel.addElement(iter.next());
		}
		
	}
	
	
}
