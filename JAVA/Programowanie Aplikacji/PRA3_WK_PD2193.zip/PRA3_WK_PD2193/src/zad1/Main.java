/**
 *
 *  @author Więcko Konrad PD2193
 *
 */

package zad1;


public class Main {

  public static void main(String[] args) {
  }
}
