package zad1;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EtchedBorder;

public class Gui extends JFrame{
	// layout opts
	final int numOfLabs = 5;
	final int initialFontSize = 10;
	String labelPosition[] = { "West", "North", "East", "South", "Center" };
	String labelText[] = {"Label1", "Label2", "Label3", "Label4", "Label5"};
	String labelFontType[] = {"Vivaldi", "DIalog", "Verdana", "Arial", "Calibri"};
	Color labelBGCol[] = {Color.red, Color.blue, Color.yellow, Color.green, Color.white};
	Color labelFGCol[] = {Color.white, Color.red, Color.black, Color.black, Color.blue};
	String labelTooltips[] = {"West", "North", "East", "South", "Center"};

	JLabel[] labels = new JLabel[numOfLabs];
	
	public Gui(){
		JFrame borderLabelLayout = new JFrame("Zadanie 1.");
		borderLabelLayout.setLayout(new BorderLayout(50,0));
		makeLabelList ();
		
		
		labels[0].setBorder(BorderFactory.createLineBorder(Color.blue));
		labels[1].setBorder(BorderFactory.createRaisedBevelBorder());
		labels[2].setBorder(BorderFactory.createLoweredBevelBorder());
		labels[3].setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
		labels[4].setBorder(BorderFactory.createEmptyBorder());
		
		addLabelsToLayout(borderLabelLayout);
		  
		borderLabelLayout.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
		borderLabelLayout.pack();
		borderLabelLayout.setLocationRelativeTo(null);
		borderLabelLayout.setVisible(true);
		
	}
	
	public void addLabelsToLayout(JFrame parent){
		for (int i = 0; i < numOfLabs; i++){
			parent.add(labels[i], labelPosition[i]);
		}
	}
	
	public void makeLabelList (){
		int localFontSize = initialFontSize;
		for(int i = 0; i < numOfLabs; i++){
			localFontSize = localFontSize + i;
			labels[i] = makeAndPositionLabel(labelText[i],
							     labelFontType[i],
							     localFontSize,
							     labelBGCol[i],
							     labelFGCol[i],
							     labelTooltips[i]
							    		 );
		}
		
		
	}
	
	public JLabel makeAndPositionLabel(String labelTxt,
									 String fontType,
									 int fontSize,
									 Color bgCol,
									 Color fgCol,
									 String tooltip){
		
		JLabel myLab = new JLabel(labelTxt);
		myLab.setOpaque(true);
		myLab.setFont(new Font(fontType, Font.PLAIN, fontSize));
		myLab.setBackground(bgCol);
		myLab.setForeground(fgCol);
		myLab.setToolTipText(tooltip);
	
		return myLab;

		
	}

}
