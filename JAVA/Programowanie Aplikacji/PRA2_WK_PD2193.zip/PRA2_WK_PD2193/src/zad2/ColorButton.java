package zad2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*; 

public class ColorButton extends JFrame {
	
	final public int initialClickIndex = 0;
	
	Color butCols[] ={Color.white, Color.red, Color.blue, Color.yellow, Color.green, Color.gray}; 
	
	public ColorButton(){
		
		super("Zadanie 2.");
		setLayout(new FlowLayout());
		JButton colBut = new JButton("Click to change background color");
		// adding action listener
		colBut.addActionListener( new ActionListener() {
			 private int clickIndex = initialClickIndex;
	         public void actionPerformed(ActionEvent e) {
	        	 if(clickIndex >= (butCols.length - 1)){
	        		clickIndex = initialClickIndex;
	        	 } else {
	        		 clickIndex = clickIndex + 1;
	        	 }
	        	 JButton localSource = (JButton) e.getSource();
	        	 localSource.setBackground(butCols[clickIndex]);
	         }
	     });
		
		// adding button to frame
		add(colBut);
		
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
	
	}

}
