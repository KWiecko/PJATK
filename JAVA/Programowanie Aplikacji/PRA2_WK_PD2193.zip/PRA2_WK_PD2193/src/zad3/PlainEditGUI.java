package zad3;

import java.awt.*; 
import java.awt.event.*; 
import javax.swing.*;    
import java.util.*;
import java.util.List;
import java.io.*;
import javax.imageio.ImageIO;


public class PlainEditGUI extends JFrame implements ActionListener {
	
	public static String frameTitle = "Prosty edytor - bez tytułu";
	JTextArea mainArea = new JTextArea(20, 30);	
	JFrame mainApp = new JFrame(frameTitle);
	HashMap <String, Object> cmdMap = new HashMap <String, Object>();
	
	// Array no 1
	Color avaliableColours[] = {Color.blue, Color.yellow, Color.orange, Color.red, Color.white, Color.black, Color.green};
	String adresses[] = {"Adres Pracy", "Adres Szkoły", "Adres Domowy"};
	char fileMneno[] = {'o','s','a','x'};
	String fileAcc[] = {"control O","control S","control A","control shift X"};
	String icons[] = {"blue.gif", "yellow.gif", "orange.gif", "red.gif",  "white.gif", "black.gif", "green.gif"} ;
	// Ze względu na nieresponsywną kombinację Ctrl+X na Windowsie 10 zdecydowałem się na responsywną kombinację 
	// Ctrl+Shift+X zamykającą okno edytora
	char addressMnemo[] = {'p','s','d'};
	String addressAcc[] = {"control shift P","control shift S","control shift D"};
	File currentlyOpen = null;
	String latestDir = "."; 
	
	public PlainEditGUI(){
		
		// file menu elements
		List<JMenuItem> fileMenu = createMenuItems(0, "fileMenu","Open", "Save", "Save as ...", "Exit");
		

		// edit submenu elements
		List<JMenuItem> editAdresyMenu = createMenuItems(4, "addressMenu", "Praca", "Szkoła", "Dom");
 
		// options submenuFG elements		
		List<JMenuItem> optionsFGMenu = createMenuItems(1, "foregroundMenu","Blue", "Yellow", "Orange", "Red", "White", "Black", "Green");
		List<JMenuItem> optionsBGMenu = createMenuItems(2, "backgroundMenu", "Blue", "Yellow", "Orange", "Red", "White", "Black", "Green");
		List<JMenuItem> optionsFSMenu = createMenuItems(3, "fontMenu", "8pts", "10pts", "12pts", "14pts", "16pts", "18pts", "20pts", "22pts", "24pts");
		
		
		


		
		mainApp.setLayout(new FlowLayout());
		
		//adding text area
		
		mainApp.add(new JScrollPane(mainArea));
		
		// adding specific menus
			//adding File menu
			JMenu file = new JMenu("File");
			int count = 0;
			for(JMenuItem menuItem : fileMenu)
			{
				menuItem.setMnemonic(fileMneno[count]);
				menuItem.setAccelerator(KeyStroke.getKeyStroke(fileAcc[count]));
				count++;
				
				file.add(menuItem);
				if(menuItem.getText().equals("Save as ...")){
					JSeparator sep = new JSeparator(SwingConstants.HORIZONTAL);
					sep.setForeground(Color.red);
					sep.setBackground(Color.red);
					file.add(sep);
				}
			}
		
			//adding Edit menu
			JMenu editAdresy = new JMenu("Adresy");
			editAdresy = addItemsToMenu(editAdresy, editAdresyMenu);
			editAdresy.setBorder(BorderFactory.createRaisedBevelBorder());
			JMenu edit = new JMenu ("Edit");
			edit.add(editAdresy);
			
			//adding Options menu
			JMenu optionsFGCol = new JMenu("Foreground");
			optionsFGCol.setBorder(BorderFactory.createRaisedBevelBorder());
			optionsFGCol = addItemsToMenu(optionsFGCol, optionsFGMenu);
			
			JMenu optionsBGCol = new JMenu("Background");
			optionsBGCol.setBorder(BorderFactory.createRaisedBevelBorder());
			optionsBGCol = addItemsToMenu(optionsBGCol, optionsBGMenu);
			
			JMenu optionsFSize = new JMenu("Font Size");
			optionsFSize.setBorder(BorderFactory.createRaisedBevelBorder());
			optionsFSize = addItemsToMenu(optionsFSize, optionsFSMenu);
			
			JMenu options = new JMenu("Options");
			options.add(optionsFGCol);
			options.add(optionsBGCol);
			options.add(optionsFSize);
		
		
		
		// adding menu bar
		JMenuBar mb = new JMenuBar();
		mb.add(file);
		mb.add(edit);
		mb.add(options);
		mainApp.setJMenuBar(mb);
		
		//mb.add(edit);
		
		
		mainApp.setDefaultCloseOperation(DISPOSE_ON_CLOSE);  
		mainApp.pack();
		mainApp.setLocationRelativeTo(null);
		mainApp.setVisible(true);
	}
	
	public List<JMenuItem> createMenuItems(int arrayIndicator, String id, String ... menuItems){
		List<JMenuItem> myList = new ArrayList<JMenuItem>();
		int fontSize = 8;
		int i = 0;
		JMenuItem localItem = null;
		for(String menuItem : menuItems){
			if(arrayIndicator == 1 || arrayIndicator == 2){
				String path = "icons/" + icons[i];
				try{
					Icon icon = new ImageIcon(ImageIO.read(new File(path)));
					localItem = new JMenuItem(menuItem, icon);					
				}catch(Exception imgLoadExc){
					imgLoadExc.printStackTrace();
				}

			}else{
				localItem = new JMenuItem(menuItem);
			}
			
			localItem.setBorder(BorderFactory.createRaisedBevelBorder());
			localItem.setActionCommand(arrayIndicator+id+menuItem);
			localItem.addActionListener(this);
			
			
			switch(arrayIndicator){
			case 0: 
					break;
			case 1: cmdMap.put(arrayIndicator + id+menuItem, avaliableColours[i]);
					i++;
					break;
			case 2: cmdMap.put(arrayIndicator + id+menuItem, avaliableColours[i]);
					i++;
			break;
			case 3: cmdMap.put(arrayIndicator + id+menuItem, fontSize);
					fontSize = fontSize +2;
			 		break;
			 		
			case 4: cmdMap.put(arrayIndicator + id+menuItem, adresses[i]);
					i++;
					break;
			
			}
			
			myList.add(localItem);
			
		}	
		return myList;
	}
	
	public JMenu addItemsToMenu(JMenu parent, List<JMenuItem> itemsToAdd){
		int i = 0;
		for(JMenuItem itemToAdd : itemsToAdd) 
			{
			if(parent.getText().equals("Adresy")){
					itemToAdd.setMnemonic(addressMnemo[i]);
					itemToAdd.setAccelerator(KeyStroke.getKeyStroke(addressAcc[i]));
				}

			i++;
			parent.add(itemToAdd);
			}		
		return parent; 
	}
	

	
	@Override
	public void actionPerformed(ActionEvent e){
		
		//System.out.println(e.getActionCommand());
		String buttonCmd = e.getActionCommand();
		
		switch(Integer.parseInt(buttonCmd.substring(0,1))){
		case 0: if(buttonCmd.equals("0fileMenuOpen")){
				JFileChooser fc = new JFileChooser();
				fc.setCurrentDirectory(new File(latestDir));
				fc.setDialogTitle("Otwóz plik");
				int result = fc.showOpenDialog(mainApp);
					if(result == JFileChooser.APPROVE_OPTION){
						File file = fc.getSelectedFile();
						latestDir = file.getAbsolutePath();
						mainApp.setTitle("Prosty edytor - " + file.getAbsolutePath()); 
						currentlyOpen = file;
						try{
							Scanner sc = new Scanner(file);
							mainArea.setText("");
							while(sc.hasNextLine()){
								mainArea.insert(sc.nextLine(), mainArea.getCaretPosition());
								mainArea.insert("\n", mainArea.getCaretPosition());
							}
							sc.close();
						}catch(Exception q) {
							q.printStackTrace();
						}
					}
				}
		
				if(buttonCmd.equals("0fileMenuSave") && currentlyOpen != null){
					try{

						FileWriter fw = new FileWriter(currentlyOpen);
						String fileToSave = mainArea.getText();
						fw.write(fileToSave);
						fw.close();
					}catch (Exception q1) {
						q1.printStackTrace();
					}
					
				}
				
				if(buttonCmd.equals("0fileMenuSave as ...") || currentlyOpen == null){
					JFileChooser fc = new JFileChooser();
					fc.setCurrentDirectory(new File(latestDir));
					fc.setDialogTitle("Zapisz plik");
					int saveResult = fc.showSaveDialog(mainApp);
					if(saveResult == JFileChooser.APPROVE_OPTION){
						File fileToSaveAs = fc.getSelectedFile();
						currentlyOpen = fileToSaveAs;
						latestDir = fileToSaveAs.getAbsolutePath();
						mainApp.setTitle(fileToSaveAs.getAbsolutePath());
						try{
							FileWriter fwAs = new FileWriter(fileToSaveAs);
							String StringToSaveAs = mainArea.getText();
							
							fwAs.write(StringToSaveAs);
							fwAs.close();
							
						}catch (Exception q2) {
							q2.printStackTrace();
						}
						
					}


					
				}
			
				if(buttonCmd.equals("0fileMenuExit")){
				mainApp.dispose();
				System.exit(0);
				}
				break;
		case 1: mainArea.setForeground((Color)cmdMap.get(buttonCmd)); 
				break;
		case 2: mainArea.setBackground((Color)cmdMap.get(buttonCmd)); 
				break;
		case 3: Font currentFont = mainArea.getFont();
				mainArea.setFont(new Font(currentFont.getFontName(), currentFont.getStyle(), (int)cmdMap.get(buttonCmd)));
				break;
		case 4: mainArea.insert((String)cmdMap.get(buttonCmd), mainArea.getCaretPosition());
				break;
		}
		
		
		
	}
	

}
